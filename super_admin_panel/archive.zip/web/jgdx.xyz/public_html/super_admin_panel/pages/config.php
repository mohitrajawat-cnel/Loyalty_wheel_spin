<?php
// $host = 'localhost';
// $db_username = 'root';
// $db_password = 'vertrigo';
// $db_name = 'ccrdskmy_loyality_wheel_spin';
// $host = 'localhost';
// $db_username = 'luckyspin';
// $db_password = '[ZgyAlf{JqTT';
// $db_name = 'ccrdskmy_loyality_wheel_spin';

// Set timezone
date_default_timezone_set("Asia/Kuala_Lumpur");

// changing the upload limits
ini_set('upload_max_filesize', '50M');
ini_set('post_max_size', '50M');
ini_set('max_input_time', 300);
ini_set('max_execution_time', 300);

$host_name = $_SERVER['HTTP_HOST'];

if($host_name == 'luckyspin.fun')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_luckyspin';
    $db_password = 'J]ZgIBo#h!ZJ';
    $db_name = 'qmzsrnmy_luckyspin';
    
}
else if($host_name == 'wgc33.vip')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_wgc33';
    $db_password = 'P+UTDnF[^3e6';
    $db_name = 'qmzsrnmy_wgc33.vip';
}
else if($host_name == 'spin2win.bet')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_spin2win';
    $db_password = 'Jfs9EH.V(3W5';
    $db_name = 'qmzsrnmy_spin2win.bet';
}
else if($host_name == 'skyworldsg-luckyspin.com')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_skyworldsg';
    $db_password = '{z97ZVy-2Nzj';
    $db_name = 'qmzsrnmy_skyworldsg-luckyspin.com';
}
else if($host_name == 'luckyspin.supremeworld88.com')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_luckyspin';
    $db_password = 'Ih$06C&Cy~cS';
    $db_name = 'qmzsrnmy_luckyspin.supremeworld88.com';
}
else if($host_name == 'wheel.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel_jgdx_xyz_db';
}
else if($host_name == 'luckyspin888.com')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_qmzsrnmy_luckyspin888';
    $db_password = 'M7eW&G2&6Q&!';
    $db_name = 'qmzsrnmy_luckyspin888.com';
}
else if($host_name == 'wheel001.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel001_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel001_jgdx_xyz_db';
}
else if($host_name == 'wheel002.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel002_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel002_jgdx_xyz_db';
}
else if($host_name == 'wheel003.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel003_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel003_jgdx_xyz_db';
}
else if($host_name == 'wheel004.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel004_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel004_jgdx_xyz_db';
}
else if($host_name == 'wheel005.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel005_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel005_jgdx_xyz_db';
}
else if($host_name == 'wheel006.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel006_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel006_jgdx_xyz_db';
}
else if($host_name == 'wheel007.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel007_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel007_jgdx_xyz_db';
}
else if($host_name == 'wheel008.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel008_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel008_jgdx_xyz_db';
}
else if($host_name == 'wheel009.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel009_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel009_jgdx_xyz_db';
}
else if($host_name == 'wheel010.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel010_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel010_jgdx_xyz_db';
}
else if($host_name == 'wheel011.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel011_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel011_jgdx_xyz_db';
}

else if($host_name == 'wheel012.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel012_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel012_jgdx_xyz_db';
}
else if($host_name == 'wheel013.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_wheel013_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_wheel013_jgdx_xyz_db';
}

else if($host_name == 'wheel014.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel014_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel014_jgdx_xyz_db';
}
else if($host_name == 'wheel015.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel015_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel015_jgdx_xyz_db';
}
else if($host_name == 'wheel016.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel016_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel016_jgdx_xyz_db';
}

else if($host_name == 'wheel017.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel017_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel017_jgdx_xyz_db';
}

else if($host_name == 'wheel018.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel018_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel018_jgdx_xyz_db';
}

else if($host_name == 'wheel019.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel019_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel019_jgdx_xyz_db';
}
else if($host_name == 'wheel020.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel020_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel020_jgdx_xyz_db';
}

else if($host_name == 'wheel021.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel021_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel021_jgdx_xyz_db';
}

else if($host_name == 'wheel022.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel022_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel022_jgdx_xyz_db';
}

else if($host_name == 'wheel023.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel023_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel023_jgdx_xyz_db';
}
else if($host_name == 'wheel024.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel024_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel024_jgdx_xyz_db';
}

else if($host_name == 'wheel025.jgdx.xyz')
{
    $host = 'localhost';

    $db_username = 'admin_wheel025_jgdx_xyz_db';

    $db_password = 'Uw5nHmY1kzKfuZW';

    $db_name = 'admin_wheel025_jgdx_xyz_db';
}
else if($host_name == 'supremeworld88.bonuus.io')
{  
    $host = 'localhost';

    $db_username = 'qmzsrnmy_supremeworld882';

    $db_password = '^TKtX&WPNzHD';

    $db_name = 'qmzsrnmy_supremeworld88.bonuus.io';
}
else if($host_name == 'fbads996.com')
{ 
    $host = 'localhost';

    $db_username = 'qmzsrnmy_fbads996';

    $db_password = '+.t&WXWu6Z8D';

    $db_name = 'qmzsrnmy_fbads996.com';
}
else if($host_name == 'readyforyourreview.com')
{
    $host = 'localhost';
    $db_username = 'ccrdskmy_wheel';
    $db_password = '[ZgyAlf{JqTT';
    $db_name = 'ccrdskmy_loyality_wheel_spin';
}
else if($host_name == 'jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_jgdx_xyz_db';
}
else if($host_name == 'sub.jgdx.xyz')
{
    $host = 'localhost';
    $db_username = 'admin_sub_jgdx_xyz_db';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_sub_jgdx_xyz_db';
}
else if($host_name == 'edbet321spins.com')
{
    $host = 'localhost';
    $db_username = 'admin_edbet321spins_com_database';
    $db_password = 'Uw5nHmY1kzKfuZW';
    $db_name = 'admin_edbet321spins_com_database';
}




$http_or_http = $_SERVER['REQUEST_SCHEME'];
if($http_or_http == 'http')
{
    
}

$conn  = mysqli_connect($host,$db_username,$db_password,$db_name);


define('Site_URL',$http_or_http.'://'.$host_name.'/admin_panel/pages');
define('Super_Site_URL',$http_or_http.'://'.$host_name.'/super_admin_panel/pages');
define('Front_URL',$http_or_http.'://'.$host_name);



//////
define('ciphering', 'AES-128-CTR');
define('encryption_iv', '1234567891011121');
define('encryption_key', 'loyalty_spin_wheel');
?>