<?php
// Set timezone
date_default_timezone_set("Asia/Kuala_Lumpur");

// changing the upload limits
ini_set('upload_max_filesize', '50M');
ini_set('post_max_size', '50M');
ini_set('max_input_time', 300);
ini_set('max_execution_time', 300);

$host_name = $_SERVER['HTTP_HOST'];

$host = 'localhost';
$db_username = 'admin_asiaz_xyz_user';
$db_password = '8cfOHlXtUgJwaCvJ';
$db_name = 'admin_asiaz_xyz';

if($host_name == 'luckyspin.fun')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_luckyspin';
    $db_password = 'J]ZgIBo#h!ZJ';
    $db_name = 'qmzsrnmy_luckyspin';
    
}
else if($host_name == 'wgc33.vip')
{
    $host = 'localhost';
    $db_username = 'qmzsrnmy_wgc33';
    $db_password = 'P+UTDnF[^3e6';
    $db_name = 'qmzsrnmy_wgc33.vip';
}


$http_or_http = $_SERVER['REQUEST_SCHEME'];
if($http_or_http == 'http')
{
    
}

$conn  = mysqli_connect($host,$db_username,$db_password,$db_name);


define('Site_URL',$http_or_http.'://'.$host_name.'/super_admin_panel/pages');
define('Front_URL',$http_or_http.'://'.$host_name);



//////
define('ciphering', 'AES-128-CTR');
define('encryption_iv', '1234567891011121');
define('encryption_key', 'loyalty_spin_wheel');
?>