<?php
session_start();
include 'config.php';

if(!isset($_SESSION['admin_user_id']))
{
?>
	<script>
    window.location.href='<?php echo Site_URL; ?>/login.php';
    </script>
<?php
}


$id=$_REQUEST['id'];

$update_msg='';
$alert_class='';
if(isset($_POST['update_function_setting']))
{
    $db_name        =   $_POST['db_name'];
    $db_user        =   $_POST['db_user'];
    $db_password        =   $_POST['db_password'];
    $status_hwe        =   $_POST['status_hwe'];

    $code_hwe        =   $_POST['code_hwe'];
	  $code_with_remain_spin       =   $_POST['code_with_remain_spin'];
	  $mobile_number           =   $_POST['mobile_number'];
	  $user_login        =   $_POST['user_login'];

    $email_method           =   $_POST['email_method'];
	  $name_email_mobileno       =   $_POST['name_email_mobileno'];

    $phone_password_with_otp_method          =   $_POST['phone_password_with_otp_method'];
	  $pnone_email_password_with_otp       =   $_POST['pnone_email_password_with_otp'];

	  $first_layout  =   $_POST['first_layout'];
	  $second_layout =$_POST['second_layout'];
    $third_layout =$_POST['third_layout'];	 
    $fourth_layout =$_POST['fourth_layout'];	  

    $sms_function        =   $_POST['sms_function'];
	  $firebase_key  =   $_POST['firebase_key'];
	  $firebase_password =$_POST['firebase_password'];
    $share_content_text =$_POST['share_content_text'];
    $share_content_title =$_POST['share_content_title'];
    $share_content_Url =$_POST['share_content_Url'];

    $sms_function_text1 =$_POST['sms_function_text1'];	
    $sms_function_text2 =$_POST['sms_function_text2'];
    
    
    $admin_redeem_button_enable       =   $_POST['admin_redeem_button_enable'];

    $lucky_number_option =$_POST['lucky_number_option'];
    
    $mobile_num_otp_hwe =$_POST['mobile_num_otp'];	

    $share_referrel =$_POST['share_referrel'];

    $bg_music =$_POST['bg_music'];
    
    $user_login_sms_function =$_POST['user_login_sms_function'];

    $bg_music_query='';
  
    if($_FILES['upload_bg_music']['name'] && $_FILES['upload_bg_music']['name'] !='')
    {
      $upload_music =$_FILES['upload_bg_music']['name'];
      $tmp_name_music = $_FILES['upload_bg_music']['tmp_name'];

      move_uploaded_file($tmp_name_music,'media/'.$upload_music);
 

      $bg_music_query = "bg_music_name ='".$upload_music."',";
    }
    

    

    
    
    $update ="UPDATE domain_list_settings SET
       `db_name`='".$db_name."',
       db_user='".$db_user."',
       db_password='".$db_password."',
       status='".$status_hwe."',
       code='".$code_hwe."',
       code_with_remain_spin='".$code_with_remain_spin."',
       mobile_number='".$mobile_number."',
       user_login='".$user_login."',
       email_method='".$email_method."',
       name_email_mobileno='".$name_email_mobileno."',
       first_layout='".$first_layout."',
       second_layout='".$second_layout."',
       third_layout='".$third_layout."',
       fourth_layout ='".$fourth_layout."',
       sms_function='".$sms_function."',
       firebase_key='".$firebase_key."',
       firebase_password='".$firebase_password."',
       share_content_text='".$share_content_text."',
       share_content_title='".$share_content_title."',
       share_content_Url='".$share_content_Url."',
       mobile_num_otp = '".$mobile_num_otp_hwe."',
       share_referrel ='".$share_referrel."',
       ".$bg_music_query."
       bg_music ='".$bg_music."',
       user_login_sms_function ='".$user_login_sms_function."',
       sms_function_text1 = '".$sms_function_text1."',
       sms_function_text2 = '".$sms_function_text2."',
       lucky_number_option = '".$lucky_number_option."',
       admin_redeem_button_enable='".$admin_redeem_button_enable."',
       phone_password_with_otp_method='".$phone_password_with_otp_method."',
       pnone_email_password_with_otp='".$pnone_email_password_with_otp."'
      where id='".$id."' ";

   mysqli_query($conn,$update);

  $update_msg='Update Record Successfully';
  $alert_class="alert alert-success";
}

//////////////////////get domain list data
$select ="SELECT * from domain_list_settings where id='".$id."'";
$row =$conn->query($select);
while($result =mysqli_fetch_assoc($row))
{
   $domain_name = $result['domain_name'];
   $db_name = $result['db_name'];
   $db_user = $result['db_user'];
   $db_password = $result['db_password'];
   $status = $result['status'];
   $code_hwe = $result['code'];
   $code_with_remain_spin=$result['code_with_remain_spin'];
   $mobile_number=$result['mobile_number'];
   $user_login = $result['user_login'];

   $email_method_get           =   $result['email_method'];
   $name_email_mobileno_get      =   $result['name_email_mobileno'];

   $phone_password_with_otp_method_hwe = $result['phone_password_with_otp_method'];
   $pnone_email_password_with_otp_hwe =$result['pnone_email_password_with_otp'];

   $first_layout  =   $result['first_layout'];
   $second_layout =$result['second_layout'];
   $third_layout =$result['third_layout'];
   $fourth_layout =$result['fourth_layout'];

   $sms_function = $result['sms_function'];
   $firebase_key = $result['firebase_key'];
   $firebase_password = $result['firebase_password'];
   $sms_function_text1 =$result['sms_function_text1'];
   $sms_function_text2=$result['sms_function_text2'];

   $lucky_number_option=$result['lucky_number_option'];

   $admin_redeem_button_enable = $result['admin_redeem_button_enable'];

   $mobile_num_otp = $result['mobile_num_otp'];

   $share_referrel_hwe = $result['share_referrel'];
   $share_content_text = $result['share_content_text'];
   $share_content_title = $result['share_content_title'];
   $share_content_Url = $result['share_content_Url'];

   $bg_music = $result['bg_music'];
   $user_login_sms_function = $result['user_login_sms_function'];
   $bg_music_name = $result['bg_music_name'];
}

?>
<style>
 .radio
{
  cursor:pointer;
}
</style>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Function Settings
  </title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css"
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <!-- CSS Files -->
  <link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet" />
</head>

<style>

.form_data{
  padding: 0rem 1rem;
}

.form_data input{
  border: 1px solid #dbdbdb;
  padding-left: 5px;
}

.form_data label{
 margin-top: 1rem;
}

</style>

<body class="g-sidenav-show  bg-gray-200">
  <?php include 'header.php'; ?>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur"
      navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <h6 class="font-weight-bolder mb-0">Function Settings</h6>
        </nav>
      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
              <div class="bg-gradient-primary shadow-primary border-radius-lg pt-2 pb-1">
                <div class="row">
                  <div class="col-md-12 pt-2">
                    <h6 class="text-white text-capitalize ps-3">Settings 
                    <a href="/super_admin_panel/pages/domains.php" style=" margin-left: 10px; background-color: black;
" class="btn btn-primary">Back</a> &nbsp;(<?php echo $domain_name; ?>)
                    </h6>
                  </div>
                </div>
              </div>
            </div>
            <div class="<?php //echo $alert_class; ?>" style="text-align:center;"><?php echo $update_msg; ?></div>
            <div class="card-body px-0 pb-2">
              <form class="form_data" method="post" enctype="multipart/form-data">

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>DB Name</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <input type="text" name="db_name" autocomplete="off" placeholder="Enter Database Name" value="<?php echo $db_name; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>DB User</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <input type="text" name="db_user" autocomplete="off" placeholder="Enter Database Name" value="<?php echo $db_user; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>DB Password</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <input type="password" name="db_password" autocomplete="off" placeholder="Enter Database Name" value="<?php echo $db_password; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Status</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($status == 1){ echo "checked"; } ?> class="radio" value="1" name="status_hwe" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($status == 0){ echo "checked"; } ?> class="radio" value="0" name="status_hwe" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Code</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($code_hwe == 1){ echo "checked"; } ?> class="radio" value="1" name="code_hwe" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($code_hwe == 0){ echo "checked"; } ?> class="radio" value="0" id="code_hwe" name="code_hwe" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Code with remain spin</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($code_with_remain_spin== 1){ echo "checked"; } ?> class="radio" value="1" name="code_with_remain_spin" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($code_with_remain_spin== 0){ echo "checked"; } ?> class="radio" value="0" id="code_with_remain_spin" name="code_with_remain_spin" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Mobile number</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($mobile_number== 1){ echo "checked"; } ?> class="radio" value="1" name="mobile_number" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($mobile_number== 0){ echo "checked"; } ?> class="radio" value="0"  id="mobile_number" name="mobile_number" placeholder="Enter Database Password" >
                    
                    </div>
                </div>  
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>User Login</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($user_login == 1){ echo "checked"; } ?> class="radio" value="1" name="user_login" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($user_login == 0){ echo "checked"; } ?> class="radio" value="0" id="user_login" name="user_login" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Email Login</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($email_method_get == 1){ echo "checked"; } ?> class="radio" value="1" name="email_method" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($email_method_get == 0){ echo "checked"; } ?> class="radio" value="0" id="email_method" name="email_method" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Name & Email & Mobile Login</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($name_email_mobileno == 1){ echo "checked"; } ?> class="radio" value="1" name="name_email_mobileno" placeholder="Enter Email" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($name_email_mobileno == 0){ echo "checked"; } ?> class="radio" value="0" id="name_email_mobileno" name="name_email_mobileno" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Mobile Number with OTP & Password Method </b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($phone_password_with_otp_method_hwe == 1){ echo "checked"; } ?> class="radio" value="1" name="phone_password_with_otp_method" placeholder="Enter Email" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($phone_password_with_otp_method_hwe == 0){ echo "checked"; } ?> class="radio" value="0" id="phone_password_with_otp_method" name="phone_password_with_otp_method" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Mobile Number with OTP & Password & Email Method</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($pnone_email_password_with_otp_hwe == 1){ echo "checked"; } ?> class="radio" value="1" name="pnone_email_password_with_otp" placeholder="Enter Email" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($pnone_email_password_with_otp_hwe == 0){ echo "checked"; } ?> class="radio" value="0" id="pnone_email_password_with_otp" name="pnone_email_password_with_otp" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>First layout</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($first_layout == 1){ echo "checked"; } ?> class="radio" value="1" name="first_layout" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($first_layout == 0){ echo "checked"; } ?> class="radio" value="0"  id="first_layout" name="first_layout" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Second Layout</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($second_layout == 1){ echo "checked"; } ?> class="radio" value="1" name="second_layout" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($second_layout == 0){ echo "checked"; } ?> class="radio" value="0"  id="second_layout" name="second_layout" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Third Layout</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($third_layout == 1){ echo "checked"; } ?> class="radio" value="1" name="third_layout" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($third_layout == 0){ echo "checked"; } ?> class="radio" value="0"  id="third_layout" name="third_layout" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Fourth Layout</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($fourth_layout == 1){ echo "checked"; } ?> class="radio" value="1" name="fourth_layout" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($fourth_layout == 0){ echo "checked"; } ?> class="radio" value="0"  id="fourth_layout" name="fourth_layout" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>SMS Function</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($sms_function == 1){ echo "checked"; } ?> class="radio sms_function" value="1" name="sms_function" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($sms_function == 0){ echo "checked"; } ?> class="radio sms_function" value="0"  id="sms_function" name="sms_function" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                <?php
                
                if($sms_function == '1')
                {
                  $show_firebase_password = 'style="display:block;"';
                }
                else
                {
                  $show_firebase_password = 'style="display:none;"';
                }
                ?>
                <div id="firebase_details" <?php echo $show_firebase_password; ?> >
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>Enter Firebase Key</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" name="firebase_key" autocomplete="off" placeholder="Enter Firebase Key" value="<?php echo $firebase_key; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div>
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>Enter Firebase Password</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" name="firebase_password" autocomplete="off" placeholder="Enter Firebase Password" value="<?php echo $firebase_password; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div>  
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>SMS Message Text 1</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" name="sms_function_text1" autocomplete="off" placeholder="Enter SMS Message Text 1" value="<?php echo $sms_function_text1; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div> 
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>SMS Message Text 2</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" name="sms_function_text2" autocomplete="off" placeholder="Enter SMS Message Text 2" value="<?php echo $sms_function_text2; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div> 
                </div>


                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Mobile Number With OTP</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($mobile_num_otp== 1){ echo "checked"; } ?> class="radio" value="1" name="mobile_num_otp" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($mobile_num_otp== 0){ echo "checked"; } ?> class="radio" value="0"  id="mobile_num_otp" name="mobile_num_otp" placeholder="Enter Database Password" >
                    
                    </div>
                </div>  

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Share Link</b></label>
                   </div> 
                    <div class="form-group col-md-6">

                    <label>Refeerer Share</label>
                        <input type="radio" <?php if($share_referrel_hwe== 1){ echo "checked";} ?> class="radio" value="1"  name="share_referrel" placeholder="Enter Database Password" >

                        <label>Normal Share</label>
                        <input type="radio" <?php if($share_referrel_hwe== 0){ echo "checked"; } ?> class="radio" value="0" name="share_referrel" placeholder="Enter Database Password">
                    
                    </div>
                </div> 
                <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>Share Content Text</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" name="share_content_text" autocomplete="off" placeholder="Enter your content text" value="<?php echo $share_content_text; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div>  
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>Share Content Title</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" name="share_content_title" autocomplete="off" placeholder="Enter your content Title" value="<?php echo $share_content_title; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div>  
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>Share Content URL</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                      <input type="text" id="share_content_Url" name="share_content_Url" autocomplete="off" placeholder="Enter your url" value="<?php echo $share_content_Url; ?>" style="font-size: 14px; padding: 5px; width: 50%;">            
                    </div>
                  </div>  
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Background Music Function</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($bg_music == 1){ echo "checked"; } ?> class="radio bg_music" value="1" name="bg_music" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($bg_music == 0){ echo "checked"; } ?> class="radio bg_music" value="0"  id="bg_music" name="bg_music" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>User Login SMS Function</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($user_login_sms_function == 1){ echo "checked"; } ?> class="radio bg_music" value="1" name="user_login_sms_function" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($user_login_sms_function == 0){ echo "checked"; } ?> class="radio bg_music" value="0"  id="user_login_sms_function" name="user_login_sms_function" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Lucky Number Option</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Lucky Number Spin</label>
                        <input type="radio" <?php if($lucky_number_option == 1){ echo "checked"; } ?> class="radio bg_music" value="1" name="lucky_number_option" placeholder="Enter Database Password" >
            
                        <label>Normal Spin</label>
                        <input type="radio" <?php if($lucky_number_option == 0){ echo "checked"; } ?> class="radio bg_music" value="0"  id="lucky_number_option" name="lucky_number_option" placeholder="Enter Database Password" >
                    
                    </div>
                </div>

                <div class="row">  
                   <div class="form-group col-md-6">
                     <label><b>Admin Redeem Button Enable</b></label>
                   </div> 
                    <div class="form-group col-md-6">
                        <label>Active</label>
                        <input type="radio" <?php if($admin_redeem_button_enable == 1){ echo "checked"; } ?> class="radio" value="1" name="admin_redeem_button_enable" placeholder="Enter Database Password" >
            
                        <label>Deactive</label>
                        <input type="radio" <?php if($admin_redeem_button_enable == 0){ echo "checked"; } ?> class="radio" value="0"  id="admin_redeem_button_enable" name="admin_redeem_button_enable" placeholder="Enter Database Password" >
                    
                    </div>
                </div>
                
                <?php
                
                if($bg_music == '1')
                {
                  $show_bg_input = 'style="display:block;"';
                }
                else
                {
                  $show_bg_input = 'style="display:none;"';
                }
                ?>
                <div id="background_music_input" <?php echo $show_bg_input; ?> >
                  <div class="row">  
                    <div class="form-group col-md-6">
                        <label><b>Upload Background Music</b></label>
                    </div> 
                    <div class="form-group col-md-6">
                       <label class="btn btn-default btn-upload " for="banner_image" style="margin-top: 0px;">
                        Choose Image
                        <input id="upload_bg_music" type="file"  name="upload_bg_music" ><span><?php echo $bg_music_name; ?></span>                        
                      </label>
                    
                    </div>
                  </div>
           
                </div>

                
                
                <div class="form-group mt-4">
                  <button type="submit" name="update_function_setting" class="btn btn-primary">Submit</button>
                </div>

              </form>
            </div>
          </div>
        </div>
      </div>



  </main>
  <div class="fixed-plugin">

    <div class="card shadow-lg">
      <div class="card-header pb-0 pt-3">

        <div class="float-end mt-4">
          <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
            <i class="material-icons">clear</i>
          </button>
        </div>
        <!-- End Toggle Button -->
      </div>
      <hr class="horizontal dark my-1">
      <div class="card-body pt-sm-3 pt-0">
        <!-- Sidebar Backgrounds -->
        <div>
          <h6 class="mb-0">Sidebar Colors</h6>
        </div>


        <!--   Core JS Files   -->
        <script src="../assets/js/core/popper.min.js"></script>
        <script src="../assets/js/core/bootstrap.min.js"></script>
        <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
        <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script>
          $(document).ready(function(e) {
            // $('input[type=radio][name=second_layout]').change(function() {
            //       if(this.value==1)
            //       {
            //             value = 0;
            //             $("input[name=first_layout][value=" + value + "]").prop('checked', true);
            //       }
            //       else
            //       {
            //             value = 1;
            //             $("input[name=first_layout][value=" + value + "]").prop('checked', true);
            //       }
            //   });

              // $('input[type=radio][name=first_layout]').change(function() {
              //     if(this.value==1)
              //     {
              //           value = 0;
              //           $("input[name=second_layout][value=" + value + "]").prop('checked', true);
              //           $("input[name=fourth_layout][value=" + value + "]").prop('checked', true);
              //     }
              //     else
              //     {
              //           value = 1;
              //           $("input[name=second_layout][value=" + value + "]").prop('checked', true);
              //           $("input[name=fourth_layout][value=" + value + "]").prop('checked', true);
              //     }
              // });

              
              $('input[type=radio][name=first_layout]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=second_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=third_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=fourth_layout][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=second_layout]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=first_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=third_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=fourth_layout][value=" + value + "]").prop('checked', true);
                  }                 
              });
            //
              $('input[type=radio][name=third_layout]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=first_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=second_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=fourth_layout][value=" + value + "]").prop('checked', true);
                  }                 
              });
//
              $('input[type=radio][name=fourth_layout]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=first_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=second_layout][value=" + value + "]").prop('checked', true);
                        $("input[name=third_layout][value=" + value + "]").prop('checked', true);
                  }                 
              });
              


              ////user login option
              $('input[type=radio][name=code_hwe]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                         $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                         $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=code_with_remain_spin]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                         $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                         $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=mobile_number]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                         $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                         $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=user_login]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                         $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                         $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=email_method]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                        $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=name_email_mobileno]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                        $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=phone_password_with_otp_method]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                        $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                         $("input[name=pnone_email_password_with_otp][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=pnone_email_password_with_otp]').change(function() {
                  if(this.value==1)
                  {
                        value = 0;
                        $("input[name=code_with_remain_spin][value=" + value + "]").prop('checked', true);
                        $("input[name=mobile_number][value=" + value + "]").prop('checked', true);
                        $("input[name=code_hwe][value=" + value + "]").prop('checked', true);
                        $("input[name=user_login][value=" + value + "]").prop('checked', true);
                        $("input[name=email_method][value=" + value + "]").prop('checked', true);
                        $("input[name=name_email_mobileno][value=" + value + "]").prop('checked', true);
                         $("input[name=phone_password_with_otp_method][value=" + value + "]").prop('checked', true);
                  }                 
              });

              $('input[type=radio][name=sms_function]').change(function() {
                var get_val_hwe = $(this).val();
                  if(get_val_hwe==1)
                  {
                       
                        $("input[name=sms_function][value=" + get_val_hwe + "]").prop('checked', true);
                        $("#firebase_details").attr('style','display:block;');
                  }
                  else
                  {
                      
                        $("input[name=sms_function][value=" + get_val_hwe + "]").prop('checked', true);
                        $("#firebase_details").attr('style','display:none;');
                  }
              });

              $('input[type=radio][name=bg_music]').change(function() {
                var get_val_hwe1 = $(this).val();
                  if(get_val_hwe1==1)
                  {
                       
                        $("input[name=bg_music][value=" + get_val_hwe1 + "]").prop('checked', true);
                        $("#background_music_input").attr('style','display:block;');
                  }
                  else
                  {
                      
                        $("input[name=bg_music][value=" + get_val_hwe1 + "]").prop('checked', true);
                        $("#background_music_input").attr('style','display:none;');
                  }
              });
              $('input[type=radio][name=share_referrel]').change(function() {
                var get_val_hwe = $(this).val();
                  if(get_val_hwe==1)
                  {
                        $("#share_content_Url").attr('style','display:none;');
                  }
                  else
                  {
                      
                        $("#share_content_Url").attr('style','display:block;');
                  }
              });


          });

          var win = navigator.platform.indexOf('Win') > -1;
          if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
              damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
          }
        </script>
        <!-- Github buttons -->
        <script async defer src="https://buttons.github.io/buttons.js"></script>
        <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
        <script src="../assets/js/material-dashboard.min.js?v=3.0.0"></script>
</body>
</html>